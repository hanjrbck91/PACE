/* Pace — frontend logic. Vanilla JS, no framework, no build, no web fonts.
 *
 * The Apps Script backend (frozen; see ../docs/api.md) owns every financial
 * number. This file reads the state, paints the ledger page, and logs
 * expenses. It NEVER recomputes finances — the only local arithmetic is
 * turning backend values into a bar fill fraction and a display tier.
 *
 * Network: one GET (?action=all) on open; one POST per expense whose response
 * already carries { transaction, state } — applied directly, no follow-up GET.
 */

(function () {
  "use strict";

  var API = (window.PACE_API_URL || "").trim();

  // ---- session (Multi-User V1: access codes + guest) --------------------
  // The backend issues a signed session token after a valid access code (or a
  // guest entry). We keep ONLY that token + the profile name; the access code
  // is never stored. `session.user` is used purely to namespace local data and
  // label the UI - the backend re-derives identity from the token on every call,
  // so editing it in the browser grants nothing.
  var SESSION_KEY = "pace_session_v1";
  var session = null;                       // { token, user, mode }
  var PROFILE_LABEL = { MUHAMMED: "Personal", FRIEND: "Friend", GUEST: "Guest (demo)" };
  function loadSession() {
    try {
      var s = JSON.parse(localStorage.getItem(SESSION_KEY));
      if (s && typeof s.token === "string" && typeof s.user === "string") return s;
    } catch (e) {}
    return null;
  }
  function saveSession(s) { try { localStorage.setItem(SESSION_KEY, JSON.stringify(s)); } catch (e) {} }
  function clearSession() { try { localStorage.removeItem(SESSION_KEY); } catch (e) {} }

  var $ = function (id) { return document.getElementById(id); };

  // ---- currency (Multi-Currency V1) ------------------------------------
  // Display-only metadata: Pace NEVER converts money. Changing currency just
  // re-labels the same numeric values. The choice lives in localStorage
  // (instant, no network write), seeded from settings.currency, default INR.
  var CURRENCIES = {
    INR: { code: "INR", name: "Indian Rupee",   symbol: "₹",    locale: "en-IN", before: true,  space: false },
    MAD: { code: "MAD", name: "Moroccan Dirham", symbol: "د.م.", locale: "en",    before: true,  space: true  }, // 'en' comma grouping (ar-MA uses '.' thousands → reads like a decimal)
    IQD: { code: "IQD", name: "Iraqi Dinar",     symbol: "ع.د",  locale: "ar-IQ", before: true,  space: true  },
    RUB: { code: "RUB", name: "Russian Ruble",   symbol: "₽",    locale: "ru-RU", before: false, space: true  }
  };
  function currencyKey() { return "pace_currency_" + (session ? session.user : "NONE"); }

  function currentCurrency() {
    try { var c = localStorage.getItem(currencyKey()); if (c && CURRENCIES[c]) return c; } catch (e) {}
    var s = store.settings && store.settings.currency;
    if (s && CURRENCIES[String(s).toUpperCase()]) return String(s).toUpperCase();
    return "INR";
  }
  function setCurrency(code) {
    if (!CURRENCIES[code]) return;
    try { localStorage.setItem(currencyKey(), code); } catch (e) {}
  }

  // Central money formatter. Locale-aware grouping via Intl (Latin digits), with
  // the requested symbol placed per currency. Underlying numbers never change.
  function formatMoney(amount, code) {
    var cur = CURRENCIES[code] || CURRENCIES.INR;
    var v = Math.round(Number(amount) || 0);
    var neg = v < 0; v = Math.abs(v);
    var num;
    try {
      num = new Intl.NumberFormat(cur.locale, { maximumFractionDigits: 0, numberingSystem: "latn" }).format(v);
    } catch (e) {
      try { num = v.toLocaleString("en-US"); } catch (e2) { num = String(v); }
    }
    var body = cur.before
      ? cur.symbol + (cur.space ? " " : "") + num
      : num + (cur.space ? " " : "") + cur.symbol;
    return (neg ? "-" : "") + body;
  }

  function money(n) { return formatMoney(n, currentCurrency()); }

  // ---- local day (Local Time / Day Boundary V1) ------------------------
  // The user's Pace "today" is their DEVICE local calendar day. getFullYear/
  // getMonth/getDate are local (not UTC), so this never shifts across the UTC
  // boundary the way new Date().toISOString().slice(0,10) would. One source.
  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  function localDayKey(d) {
    d = d || new Date();
    return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate());
  }
  function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }
  function prefersReduced() {
    return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  var store = { state: null, settings: null, tx: [] };

  // ---- local state cache (stale-while-revalidate) ----------------------
  // Paint the last server-authoritative state instantly on open, then a
  // background GET replaces it. Cache is a convenience mirror only; the
  // server remains the sole source of truth (this NEVER recomputes finances).
  // Cache is namespaced per profile: one profile can never hydrate another's numbers.
  function cacheKey() { return "pace_cache_v1_" + (session ? session.user : "NONE"); }
  var CACHE_VERSION = 1;

  function saveCache() {
    if (!store.state) return;
    try {
      localStorage.setItem(cacheKey(), JSON.stringify({
        v: CACHE_VERSION,
        ts: Date.now(),
        state: store.state,
        tx: store.tx || [],
        settings: store.settings || {}
      }));
    } catch (e) { /* private mode / quota — caching is best-effort */ }
  }

  // Returns a valid { state, tx, settings, ts } or null. Fails safe on
  // malformed JSON, missing fields, or an old cache version.
  function loadCache() {
    var raw;
    try { raw = localStorage.getItem(cacheKey()); }
    catch (e) { return null; }
    if (!raw) return null;
    var c;
    try { c = JSON.parse(raw); }
    catch (e) { return null; }
    if (!c || c.v !== CACHE_VERSION) return null;
    var s = c.state;
    // minimal shape check — the fields render() actually reads
    if (!s || typeof s !== "object") return null;
    if (typeof s.today_pace !== "number" || typeof s.remaining_pace !== "number") return null;
    if (!s.month || typeof s.month !== "object") return null;
    if (!Array.isArray(c.tx)) return null;
    if (!c.settings || typeof c.settings !== "object") return null;
    return { state: s, tx: c.tx, settings: c.settings, ts: c.ts };
  }

  function clearCache() {
    try { localStorage.removeItem(cacheKey()); } catch (e) {}
  }

  // subtle, non-blocking "sync unavailable" note (injected, no design change)
  var syncNote = null;
  function showSyncNote() {
    if (!syncNote) {
      syncNote = document.createElement("p");
      syncNote.id = "syncNote";
      syncNote.setAttribute("role", "status");
      syncNote.style.cssText =
        "font-family:var(--mono);font-size:11px;color:var(--dim);" +
        "font-style:italic;padding:6px 0 0;margin:0;";
      var ctx = document.getElementById("ctx");
      if (ctx && ctx.parentNode) ctx.parentNode.insertBefore(syncNote, ctx.nextSibling);
    }
    syncNote.textContent = "Sync unavailable — showing last saved.";
    syncNote.hidden = false;
  }
  function clearSyncNote() { if (syncNote) syncNote.hidden = true; }

  // ---- optimistic logging (Phase 1B) -----------------------------------
  // On submit we show the expense + its consequence instantly, then the POST
  // reconciles against the authoritative server state. We do NOT invent a new
  // pace algorithm: today_pace is left untouched (beginning-of-day semantics),
  // and the incremental effect of one expense is applied to the aggregates
  // exactly as the backend's documented output relations define them. The
  // server response always overwrites this optimistic guess.
  var submitting = false;   // re-entry / double-tap guard
  var tmpSeq = 0;
  function newTempId() { return "tmp_" + Date.now() + "_" + (++tmpSeq); }

  // Optimistic state shift for a signed amount on TODAY. Add passes +amount /
  // countDelta +1 (unchanged). Corrections reuse it: delete/undo -amount / -1,
  // edit +(new-old) / 0. today_pace never moves (start-of-day semantics); all
  // corrections in this app act on today's transactions.
  function computeOptimistic(prev, amount, countDelta) {
    if (countDelta === undefined) countDelta = 1;
    var s = Object.assign({}, prev);        // shallow clone; nested month/inputs untouched
    var pace = Number(prev.today_pace) || 0;
    s.spent_today          = (Number(prev.spent_today) || 0) + amount;
    s.actual_spend_to_date = (Number(prev.actual_spend_to_date) || 0) + amount;
    s.today_variance       = s.spent_today - pace;              // today_pace unchanged
    s.remaining_spendable  = (Number(prev.remaining_spendable) || 0) - amount;
    s.current_balance      = (Number(prev.current_balance) || 0) - amount;
    s.pace                 = (Number(prev.pace) || 0) + amount; // month view only
    var daysAfter = (prev.month && Number(prev.month.days_remaining)) || 0;
    s.remaining_pace       = daysAfter > 0 ? Math.max(s.remaining_spendable, 0) / daysAfter : 0;
    // status: mirrors the backend's documented rule exactly (no second algorithm)
    var eps = Math.max(0.5, pace * 0.005);
    if (s.remaining_spendable <= 0)        s.status = "over";
    else if (s.spent_today > pace + eps)   s.status = "over";
    else if (s.spent_today < pace - eps)   s.status = "under";
    else                                    s.status = "on_track";
    s.remaining_discretionary       = s.remaining_spendable;    // keep aliases consistent
    s.safe_daily_for_rest_of_month  = s.remaining_pace;
    s.transaction_count = (Number(prev.transaction_count) || 0) + countDelta;
    return s;
  }

  // non-blocking rollback notice on the main page (reuses existing tokens)
  var logNote = null;
  function showLogError(msg) {
    if (!logNote) {
      logNote = document.createElement("p");
      logNote.id = "logNote";
      logNote.setAttribute("role", "alert");
      logNote.style.cssText =
        "font-family:var(--mono);font-size:12px;color:var(--red);padding:6px 0 0;margin:0;";
      var ctx = document.getElementById("ctx");
      if (ctx && ctx.parentNode) ctx.parentNode.insertBefore(logNote, ctx.nextSibling);
    }
    logNote.textContent = msg;
    logNote.hidden = false;
    clearTimeout(logNote._t);
    logNote._t = setTimeout(function () { logNote.hidden = true; }, 6000);
  }

  // ---- large-expense confirmation (Expense Safety 1) -------------------
  // A sanity check, NOT a limit: warn before an unusually large amount so a
  // typo (₹25,434 for ₹2,543) is caught, but always let the user continue.
  // Thresholds are constants (tune later after real use), never user settings.
  var LARGE_EXPENSE_PACE_MULTIPLIER = 5;     // > 5× today's pace
  var LARGE_EXPENSE_REMAINING_RATIO = 0.25;  // > 25% of remaining spendable

  function isLargeExpense(val) {
    var s = store.state;
    if (!s || !(val > 0)) return false;
    var pace = Number(s.today_pace) || 0;
    var rem = Number(s.remaining_spendable) || 0;
    if (pace > 0 && val > LARGE_EXPENSE_PACE_MULTIPLIER * pace) return true;
    // only use the remaining-ratio rule when there is a positive pool left
    if (rem > 0 && val > LARGE_EXPENSE_REMAINING_RATIO * rem) return true;
    return false;
  }

  // Shows the paper-styled confirmation inside the existing sheet. It NEVER
  // submits by itself — only its "Log expense" calls back into the real flow.
  function showLargeConfirm(val, amount, note, btn, msg, form) {
    if (form) form.hidden = true;
    var old = document.getElementById("largeConfirm");
    if (old) old.parentNode.removeChild(old);

    var box = el("div", "confirm");
    box.id = "largeConfirm";
    box.setAttribute("role", "group");
    box.setAttribute("aria-label", "Large expense confirmation");

    box.appendChild(el("p", "confirm__kicker", "Large expense"));
    var pace = Number(store.state.today_pace) || 0;
    box.appendChild(el("p", "confirm__amount", money(val)));
    box.appendChild(el("p", "confirm__body",
      money(val) + " is much larger than your pace of " + money(pace) +
      " / day. This will noticeably change your spending trajectory."));
    box.appendChild(el("p", "confirm__ask", "Log it anyway?"));

    var actions = el("div", "confirm__actions");
    var cancel = el("button", "confirm__cancel", "Cancel");
    cancel.type = "button";
    var go = el("button", "confirm__go", "Log expense");
    go.type = "button";
    actions.appendChild(cancel);
    actions.appendChild(go);
    box.appendChild(actions);
    sheetContent.appendChild(box);

    function close() { if (box.parentNode) box.parentNode.removeChild(box); }

    cancel.addEventListener("click", function () {
      close();
      if (form) form.hidden = false;      // amount stays in the field for editing
      if (amount) amount.focus();
    });
    go.addEventListener("click", function () {
      go.disabled = true;                 // block a double-tap on confirm itself
      close();
      submitExpense(amount, note, btn, msg, form, true); // proceed, confirmed
    });

    // focus Cancel by default so a stray Enter/tap can't confirm accidentally
    cancel.focus();
  }

  // ---- transaction corrections: Undo / Edit / Delete (Expense Safety 2) -
  // Destructive ops are NOT optimistic — correctness over perceived speed. Each
  // waits for the authoritative backend result, then reconciles + caches. Backend
  // is addressed by transaction_id and delete is idempotent (already-absent = ok),
  // so a timeout-retry never double-deletes. opInFlight blocks a second op on the
  // same id (double-tap / edit-while-pending).
  var UNDO_WINDOW_MS = 8000;   // Undo affordance lifetime after a successful log
  var opInFlight = {};         // transaction_id -> true while a mutation is pending

  // Optimistic delete/undo: remove the row + shift Pace immediately, POST in the
  // background, reconcile to authoritative state on success, surgically restore
  // the exact row + reverse the Pace delta on failure. Rollback is scoped to THIS
  // transaction (re-insert its object, reverse its amount) so a concurrent op on a
  // different id is never clobbered. opInFlight blocks a second op on the same id.
  function performDelete(id, opts) {
    opts = opts || {};
    id = String(id || ""); if (!id) return;
    if (opInFlight[id]) return;               // guard: one op per transaction
    var idx = -1, txObj = null;
    for (var i = 0; i < store.tx.length; i++) {
      if (store.tx[i].transaction_id === id) { idx = i; txObj = store.tx[i]; break; }
    }
    if (idx < 0) return;                       // already gone locally — nothing to do
    opInFlight[id] = true;
    var amount = Number(txObj.amount) || 0;

    // 1. optimistic: remove + recompute now
    store.tx.splice(idx, 1);
    store.state = computeOptimistic(store.state, -amount, -1);
    render({ keepDelta: true });

    // 2. background mutation (idempotent by id; client_id keeps the retry safe)
    apiPost({ action: "deleteTransaction", transaction: { transaction_id: id }, client_id: newClientId(), today: localDayKey() })
      .then(function (data) {
        if (data.state) store.state = data.state;   // authoritative wins
        saveCache();
        render({ keepDelta: true });
      })
      .catch(function () {
        // 3. surgical rollback: re-insert the exact row, reverse the Pace delta
        store.tx.splice(Math.min(idx, store.tx.length), 0, txObj);
        store.state = computeOptimistic(store.state, +amount, +1);
        render({ keepDelta: true });
        showLogError("Couldn’t delete — restored.");
      })
      .then(function () { delete opInFlight[id]; });
  }

  // Optimistic edit: apply the new amount/note + shift Pace by (new-old) now,
  // POST in the background, reconcile on success, restore the exact prior
  // amount/note + reverse the delta on failure. Same transaction_id throughout.
  function performUpdate(id, amount, note, opts) {
    opts = opts || {};
    id = String(id || ""); if (!id) return;
    if (opInFlight[id]) return;
    var txObj = null;
    for (var i = 0; i < store.tx.length; i++) {
      if (store.tx[i].transaction_id === id) { txObj = store.tx[i]; break; }
    }
    if (!txObj) return;
    opInFlight[id] = true;
    var oldAmount = Number(txObj.amount) || 0, oldNote = txObj.note || "";
    var delta = amount - oldAmount;

    // 1. optimistic: edit in place + recompute now
    txObj.amount = amount; txObj.note = note;
    store.state = computeOptimistic(store.state, delta, 0);
    render({ keepDelta: true });

    // 2. background mutation
    apiPost({ action: "updateTransaction", transaction: { transaction_id: id, amount: amount, note: note }, client_id: newClientId(), today: localDayKey() })
      .then(function (data) {
        var t = data.transaction;
        if (t) { txObj.amount = t.amount; txObj.note = t.note; }   // authoritative fields
        if (data.state) store.state = data.state;
        saveCache();
        render({ keepDelta: true });
      })
      .catch(function () {
        // 3. surgical rollback: restore exact prior values, reverse the delta
        txObj.amount = oldAmount; txObj.note = oldNote;
        store.state = computeOptimistic(store.state, -delta, 0);
        render({ keepDelta: true });
        showLogError("Couldn’t save the edit — restored.");
      })
      .then(function () { delete opInFlight[id]; });
  }

  // Undo bar — applies to the MOST RECENT confirmed transaction only (MVP: single,
  // not a stack). Logging again replaces the target with the newer one.
  // The bar is shown from the OPTIMISTIC transaction (no backend id needed). The
  // target is {tempId, id, amount, cancelled}: `id` is null until the POST
  // confirms and is then promoted to the authoritative transaction_id.
  var undoBar = null, undoTimer = null, undoTarget = null;
  function showUndoBar(target) {
    undoTarget = target;
    var amount = target.amount;
    if (!undoBar) {
      undoBar = document.createElement("div");
      undoBar.id = "undoBar";
      undoBar.style.cssText = "display:flex;align-items:center;justify-content:space-between;gap:12px;padding:8px 0 0;";
      var txt = document.createElement("span");
      txt.id = "undoBarText";
      txt.style.cssText = "font-family:var(--mono);font-size:12px;color:var(--dim);";
      var btn = document.createElement("button");
      btn.id = "undoBarBtn"; btn.type = "button"; btn.textContent = "Undo";
      btn.setAttribute("aria-label", "Undo last logged expense");
      btn.style.cssText = "min-height:44px;padding:6px 16px;border:1.5px solid var(--ink);background:transparent;color:var(--ink);font-family:var(--serif);font-style:italic;font-size:15px;cursor:pointer;";
      undoBar.appendChild(txt); undoBar.appendChild(btn);
      var ctx = document.getElementById("ctx");
      if (ctx && ctx.parentNode) ctx.parentNode.insertBefore(undoBar, ctx.nextSibling);
      btn.addEventListener("click", onUndoClick);
    }
    document.getElementById("undoBarText").textContent = money(amount) + " logged";
    var b = document.getElementById("undoBarBtn"); b.disabled = false; b.textContent = "Undo";
    undoBar.hidden = false;
    clearTimeout(undoTimer);
    undoTimer = setTimeout(hideUndoBar, UNDO_WINDOW_MS);
  }
  function hideUndoBar() { if (undoBar) undoBar.hidden = true; undoTarget = null; }
  function onUndoClick() {
    var t = undoTarget; if (!t) return;
    clearTimeout(undoTimer);
    hideUndoBar();                    // close the bar immediately (optimistic)
    if (t.id) {
      performDelete(t.id);            // confirmed: optimistic remove + background delete
    } else {
      // Not confirmed yet: undo locally NOW (drop the temp row, reverse the
      // Pace delta). The in-flight add sees `cancelled` when it resolves and
      // deletes the row the server just wrote (see submitExpense).
      var had = false;
      store.tx = store.tx.filter(function (x) { if (x.__tempId === t.tempId) { had = true; return false; } return true; });
      if (had) {
        store.state = computeOptimistic(store.state, -t.amount, -1);
        render({ keepDelta: true });
      }
      t.cancelled = true;
    }
  }

  // Today's-entries sheet with per-row Edit / Delete (in-place, ledger-styled).
  function renderLogSheet() {
    sheetContent.innerHTML = "";
    var today = todaysExpenses().slice().reverse(); // newest first
    if (!today.length) { sheetContent.appendChild(el("p", "txempty", "Nothing logged today.")); return; }
    var sum = today.reduce(function (a, t) { return a + (Number(t.amount) || 0); }, 0);
    sheetContent.appendChild(el("p", "note-line",
      today.length + (today.length === 1 ? " entry" : " entries") + "  ·  " + money(sum) + " today"));
    var ul = el("ul", "txlist");
    today.forEach(function (t) {
      var li = el("li", "txrow");
      li.appendChild(el("span", "a", money(t.amount)));
      li.appendChild(el("span", "n", t.note || "—"));
      var actions = el("span", "txactions");
      var edit = el("button", "txbtn", "Edit"); edit.type = "button";
      var del = el("button", "txbtn txbtn--del", "Delete"); del.type = "button";
      if (!t.transaction_id) { edit.disabled = true; del.disabled = true; } // pending optimistic row
      edit.addEventListener("click", function () { openEditRow(li, t); });
      del.addEventListener("click", function () { openDeleteRow(li, t); });
      actions.appendChild(edit); actions.appendChild(del);
      li.appendChild(actions);
      ul.appendChild(li);
    });
    sheetContent.appendChild(ul);
  }

  function openEditRow(li, t) {
    li.innerHTML = "";
    var form = el("form", "txedit");
    var amt = el("input"); amt.type = "number"; amt.inputMode = "decimal"; amt.step = "0.01"; amt.min = "0";
    amt.value = String(t.amount); amt.className = "txedit__amt"; amt.setAttribute("aria-label", "Amount");
    var note = el("input"); note.type = "text"; note.maxLength = 80; note.value = t.note || "";
    note.className = "txedit__note"; note.setAttribute("aria-label", "Note");
    var save = el("button", "txbtn", "Save"); save.type = "submit";
    var cancel = el("button", "txbtn", "Cancel"); cancel.type = "button";
    var msg = el("p", "form-msg"); msg.hidden = true;
    form.appendChild(amt); form.appendChild(note); form.appendChild(save); form.appendChild(cancel); form.appendChild(msg);
    li.appendChild(form);
    amt.focus();
    cancel.addEventListener("click", function () { renderLogSheet(); });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = parseFloat(amt.value);
      if (!isFinite(v) || v <= 0) { flash(msg, "Enter an amount above zero.", "err"); amt.focus(); return; }
      // optimistic: render() rebuilds the sheet immediately (form closes); the
      // background update reconciles or rolls back on its own.
      performUpdate(t.transaction_id, v, note.value.trim());
    });
  }

  function openDeleteRow(li, t) {
    li.innerHTML = "";
    var box = el("div", "txconfirm");
    box.appendChild(el("span", "txconfirm__q", "Delete this expense?"));
    var cancel = el("button", "txbtn", "Cancel"); cancel.type = "button";
    var del = el("button", "txbtn txbtn--del", "Delete"); del.type = "button";
    box.appendChild(cancel); box.appendChild(del);
    li.appendChild(box);
    cancel.focus();
    cancel.addEventListener("click", function () { renderLogSheet(); });
    del.addEventListener("click", function () {
      // optimistic: render() rebuilds the sheet immediately (row + confirm gone);
      // the background delete reconciles or restores the row on failure.
      performDelete(t.transaction_id);
    });
  }

  // ---- networking (Phase 1C: timeout + conservative retry) -------------
  // Apps Script is normally slow (3–6s) and has been seen to hang ~136s, so
  // every request is bounded by a ~15s AbortController timeout. A transient
  // failure (timeout / network / non-JSON reply) is retried ONCE; a server
  // business error (ok:false, e.g. validation) is NEVER retried. The POST
  // carries a client_id so its single retry is duplicate-safe: the backend
  // dedups the id within a 90s window and still returns a fresh state.
  var REQ_TIMEOUT_MS = 15000;

  function fetchWithTimeout(url, opts, ms) {
    opts = opts || {};
    if (typeof AbortController === "undefined") return fetch(url, opts); // no-timeout fallback
    var ac = new AbortController();
    opts.signal = ac.signal;
    var to = setTimeout(function () { ac.abort(); }, ms);
    return fetch(url, opts).then(
      function (v) { clearTimeout(to); return v; },
      function (e) {
        clearTimeout(to);
        if (ac.signal.aborted) { var te = new Error("Request timed out"); te.timeout = true; throw te; }
        throw e;
      }
    );
  }
  // A failure is transient (retryable) unless it is a server business error.
  function isTransient(err) { return !(err && err.business); }

  function apiGetOnce(action) {
    // Reads are POSTs so the session token never appears in a URL. The user's
    // local day is sent so the server computes "today" in their timezone.
    return apiPostOnce({ action: action, today: localDayKey() });
  }
  function apiGet(action) {
    // GET is idempotent → safe to retry once on a transient failure.
    return apiGetOnce(action).catch(function (err) {
      if (isTransient(err)) return apiGetOnce(action);
      throw err;
    });
  }

  function apiPostOnce(payload) {
    if (session && session.token) payload = Object.assign({}, payload, { token: session.token });
    return fetchWithTimeout(API, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" }, // no CORS preflight
      body: JSON.stringify(payload)
    }, REQ_TIMEOUT_MS).then(readJson);
  }
  function apiPost(payload) {
    // Retry a POST ONCE only when it carries a client_id (backend idempotency
    // makes the retry duplicate-safe) AND the failure is transient. Without an
    // id we never auto-retry a write. Business errors are never retried.
    var hasId = !!(payload && (payload.client_id || (payload.transaction && payload.transaction.client_id)));
    return apiPostOnce(payload).catch(function (err) {
      if (hasId && isTransient(err)) return apiPostOnce(payload);
      throw err;
    });
  }

  function readJson(res) {
    return res.text().then(function (txt) {
      var body;
      try { body = JSON.parse(txt); }
      catch (e) { throw new Error("Unexpected reply from the server."); } // transient (retryable)
      if (!body || body.ok !== true) {
        var be = new Error(humanError(body && body.error));
        be.business = true;   // server-returned failure → do NOT retry
        if (body && body.error === "unauthorized" && session) onAuthLost();
        throw be;
      }
      return body.data;
    });
  }
  function humanError(raw) {
    var s = String(raw || "");
    if (/amount must be/i.test(s)) return "Enter a valid amount.";
    if (/not found/i.test(s)) return "The sheet is not set up yet.";
    if (/busy/i.test(s)) return "Server busy — try again.";
    return s || "Something went wrong on the server.";
  }
  function niceNetwork(err) {
    var m = (err && err.message) || "";
    if ((err && err.timeout) || /timed out|timeout|abort/i.test(m)) {
      return "Server timed out. Check your connection.";
    }
    if (/Failed to fetch|NetworkError|load failed/i.test(m)) {
      return "Can't reach Pace. Check your connection.";
    }
    return m || "Something went wrong.";
  }

  var newClientId = function () {
    return "c_" + Date.now() + "_" + Math.random().toString(36).slice(2, 10);
  };

  // ---- helpers ---------------------------------------------------------

  function todaysExpenses() {
    // "today" = the user's LOCAL day (matches the day new expenses are stamped
    // with and the day the server now computes state for).
    var d = localDayKey();
    return store.tx.filter(function (t) { return t.date === d && t.type === "expense"; });
  }

  // bar fill: spent as a fraction of the bar. The "today's line" mark sits at
  // 60%; under-pace fills green up to it, over-pace runs red past it toward 1.
  function barFrac(spent, pace) {
    if (!(pace > 0)) return spent > 0 ? 1 : 0;
    var r = spent / pace;
    if (r <= 1) return r * 0.60;
    return clamp(0.60 + (r - 1) * 0.40, 0.60, 1);
  }

  // display intensity tier for over-spend (does NOT change any finance)
  function overTier(spent, pace) {
    if (!(pace > 0)) return spent > 0 ? 3 : 0;
    var r = spent / pace;
    if (r <= 1.0001) return 0;
    if (r <= 1.5) return 1;
    if (r <= 3) return 2;
    return 3;
  }

  // ---- render ----------------------------------------------------------

  var prevRemaining = null; // for the "from tomorrow" change flash
  var deltaTimer = null;

  function render(opts) {
    var s = store.state;
    if (!s) return;
    opts = opts || {};

    var todayPace = Number(s.today_pace) || 0;
    var spentToday = Number(s.spent_today) || 0;
    var todayVar = Number(s.today_variance) || 0; // spent - pace (+ = over)
    var remaining = Number(s.remaining_pace) || 0;
    var leftToday = todayPace - spentToday;

    var app = $("app");
    app.removeAttribute("data-state");

    // status word + state classes
    app.classList.remove("is-over", "is-under", "is-on", "sev1", "sev2", "sev3");
    var word;
    if (s.status === "over") { word = "OVER PACE"; app.classList.add("is-over"); }
    else if (s.status === "under") { word = "UNDER PACE"; app.classList.add("is-under"); }
    else { word = "ON PACE"; app.classList.add("is-on"); }
    var tier = s.status === "over" ? overTier(spentToday, todayPace) : 0;
    if (tier) app.classList.add("sev" + tier);
    $("status").textContent = word;

    // severe stamp
    $("stamp").hidden = tier < 3;

    // diff sentence (highlighted, ledger annotation)
    var diff = $("diff");
    if (s.status === "over") {
      diff.innerHTML = "You&rsquo;re <b>" + money(todayVar) + "</b> over today&rsquo;s line.";
    } else if (s.status === "under") {
      diff.innerHTML = "You&rsquo;re <b>" + money(-todayVar) + "</b> under today&rsquo;s line.";
    } else {
      diff.innerHTML = "Right on today&rsquo;s line.";
    }

    // today's pace hero
    $("todayPace").textContent = money(todayPace);

    // pace bar
    $("barFill").style.width = (barFrac(spentToday, todayPace) * 100).toFixed(1) + "%";

    // spent / left(or over)
    $("spentLine").innerHTML = "<b>" + money(spentToday) + "</b> spent";
    var leftEl = $("leftLine");
    if (leftToday >= 0) {
      leftEl.innerHTML = "<b>" + money(leftToday) + "</b> left";
      leftEl.classList.remove("over");
    } else {
      leftEl.innerHTML = "<b>-" + money(-leftToday).replace(/^-/, "") + "</b> over";
      leftEl.classList.add("over");
    }

    // meta rows
    $("tom").textContent = money(remaining) + " / day";
    $("remain").textContent = money(s.remaining_spendable);
    var m = s.month || {};
    $("days").textContent = (m.days_remaining != null ? m.days_remaining : "—") + " days";

    // from-tomorrow change flash
    var delta = $("tomDelta");
    if (opts.showDelta && prevRemaining != null && Math.round(prevRemaining) !== Math.round(remaining)) {
      var dropped = remaining < prevRemaining;
      delta.textContent = money(prevRemaining) + (dropped ? " ↓" : " ↑");
      delta.className = "delta " + (dropped ? "drop" : "rise");
      clearTimeout(deltaTimer);
      deltaTimer = setTimeout(function () { delta.textContent = ""; delta.className = "delta"; }, 6000);
    } else if (!opts.keepDelta) {
      delta.textContent = "";
      delta.className = "delta";
    }

    // dateline
    $("ctx").textContent = fmtDate(s.as_of) + "  ·  day " + m.day_of_month + " of " + m.days_in_month;

    // today's entries (newest first, up to 3 on the page)
    renderEntries(opts.inkLast);

    $("err").hidden = true;
    if (openKind && openKind !== "add") fillSheet(openKind);
  }

  function renderEntries(inkLast) {
    var ul = $("entries");
    ul.innerHTML = "";
    var today = todaysExpenses().slice().reverse(); // newest first
    if (!today.length) {
      var li0 = document.createElement("li");
      li0.className = "empty";
      li0.textContent = "Nothing logged yet.";
      ul.appendChild(li0);
      return;
    }
    today.slice(0, 3).forEach(function (t, i) {
      var li = document.createElement("li");
      var n = document.createElement("span");
      n.className = "n"; n.textContent = t.note || "Expense";
      var a = document.createElement("span");
      a.className = "a"; a.textContent = money(t.amount);
      li.appendChild(n); li.appendChild(a);
      if (inkLast && i === 0 && !prefersReduced()) li.className = "ink-in";
      ul.appendChild(li);
    });
  }

  function fmtDate(iso) {
    if (!iso) return "";
    var parts = String(iso).split("-");
    var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    var mi = (parseInt(parts[1], 10) || 1) - 1;
    return (months[mi] || "") + " " + parseInt(parts[2], 10) + ", " + parts[0];
  }

  function fatal(msg) {
    var err = $("err");
    err.textContent = msg;
    err.hidden = false;
    $("app").removeAttribute("data-state");
  }

  // ---- bottom sheets ---------------------------------------------------

  var sheet = $("sheet"), sheetContent = $("sheetContent"), sheetTitle = $("sheetTitle");
  var openKind = null, lastFocus = null, closeTimer = null;
  var TITLES = { month: "This month", balance: "Balance", log: "Today’s entries", config: "Settings", add: "Log an expense" };

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function row(k, v, cls) {
    var d = el("div");
    d.appendChild(el("span", "rk", k));
    d.appendChild(el("span", "rv" + (cls ? " " + cls : ""), v));
    return d;
  }

  function fillSheet(kind) {
    var s = store.state, cfg = store.settings || {}, inp = (s && s.inputs) || {};
    sheetTitle.textContent = TITLES[kind] || "";
    sheetContent.innerHTML = "";

    if (kind === "month" && s) {
      var m = s.month || {};
      var w = el("div", "rows");
      w.appendChild(row("Spent so far", money(s.actual_spend_to_date)));
      w.appendChild(row("Savings target (protected)", money(inp.monthly_savings_target)));
      w.appendChild(row("Remaining spendable", money(s.remaining_spendable)));
      w.appendChild(row("Today's pace", money(s.today_pace) + " / day"));
      w.appendChild(row("Pace from tomorrow", money(s.remaining_pace) + " / day"));
      w.appendChild(row("Days elapsed", (m.days_elapsed || 0) + " of " + m.days_in_period));
      w.appendChild(row("Days remaining", String(m.days_remaining)));
      sheetContent.appendChild(w);

    } else if (kind === "balance" && s) {
      sheetContent.appendChild(el("p", "big-num", money(s.current_balance)));
      sheetContent.appendChild(el("p", "note-line",
        "Started at " + money(inp.starting_balance) + " on " + (inp.starting_balance_date || "—") +
        ". Updates with every income and expense you log."));

    } else if (kind === "log" && s) {
      renderLogSheet(); // today's entries with per-row Edit / Delete

    } else if (kind === "config") {
      var c = el("div", "rows");
      c.appendChild(row("Profile", PROFILE_LABEL[session && session.user] || "—"));
      // Currency selector (display unit only — no conversion)
      var crow = el("div");
      crow.appendChild(el("span", "rk", "Currency"));
      var sel = document.createElement("select");
      sel.className = "cur-select";
      sel.setAttribute("aria-label", "Display currency");
      var curNow = currentCurrency();
      ["INR", "MAD", "IQD", "RUB"].forEach(function (code) {
        var o = document.createElement("option");
        o.value = code;
        o.textContent = code + " — " + CURRENCIES[code].name;
        if (code === curNow) o.selected = true;
        sel.appendChild(o);
      });
      sel.addEventListener("change", function () {
        setCurrency(sel.value);
        render();            // repaint the whole app in the new currency (also refills this sheet)
      });
      crow.appendChild(sel);
      c.appendChild(crow);

      c.appendChild(row("Monthly income", money(cfg.monthly_income)));
      c.appendChild(row("Savings target", money(cfg.monthly_savings_target)));
      c.appendChild(row("Fixed expenses", money(cfg.fixed_monthly_expenses)));
      c.appendChild(row("Starting balance", money(cfg.starting_balance)));
      c.appendChild(row("Metro / weekday", money(cfg.metro_weekday_cost)));
      c.appendChild(row("Auto / week", money(cfg.weekly_auto_cost)));
      sheetContent.appendChild(c);
      sheetContent.appendChild(el("p", "hint",
        "Currency sets the display unit only — Pace never converts your money, so the numbers stay the same. Edit the amounts in the Pace Google Sheet."));

      // Account actions
      var acct = el("div", "acct");
      if (session && session.mode === "guest") {
        var rst = el("button", "txbtn", "Reset demo"); rst.type = "button";
        rst.addEventListener("click", function () { resetDemo(rst); });
        acct.appendChild(rst);
      }
      var sw = el("button", "txbtn", "Switch user"); sw.type = "button";
      sw.addEventListener("click", switchUser);
      acct.appendChild(sw);
      sheetContent.appendChild(acct);

    } else if (kind === "add") {
      sheetContent.appendChild(buildForm());
    }
  }

  function buildForm() {
    var form = el("form", "form");
    form.noValidate = true;
    var amt = el("div", "amount");
    amt.appendChild(el("span", null, (CURRENCIES[currentCurrency()] || CURRENCIES.INR).symbol));
    var amount = el("input");
    amount.type = "number"; amount.inputMode = "decimal";
    amount.step = "0.01"; amount.min = "0"; amount.placeholder = "0";
    amount.id = "amountInput"; amount.setAttribute("aria-label", "Amount in rupees");
    amt.appendChild(amount);
    form.appendChild(amt);
    var note = el("input", "note-field");
    note.type = "text"; note.maxLength = 80;
    note.placeholder = "what was it? (optional)";
    note.id = "noteInput"; note.setAttribute("aria-label", "Note");
    form.appendChild(note);
    var btn = el("button", "submit", "Log expense");
    btn.type = "submit";
    form.appendChild(btn);
    var msg = el("p", "form-msg"); msg.id = "formMsg"; msg.hidden = true;
    form.appendChild(msg);
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      submitExpense(amount, note, btn, msg, form, false);
    });
    return form;
  }

  function submitExpense(amount, note, btn, msg, form, confirmed) {
    if (submitting) return;                       // guard: ignore re-entry
    var val = parseFloat(amount.value);
    if (!isFinite(val) || val <= 0) {
      flash(msg, "Enter an amount above zero.", "err");
      amount.focus();
      return;
    }
    if (!store.state) {                           // nothing to base optimism on yet
      flash(msg, "Still loading — try again in a moment.", "err");
      return;
    }

    // Expense Safety 1: sanity-check a large amount BEFORE any submit. The
    // warning sits in front of the Phase-1B flow and never submits by itself;
    // recomputed from the current amount each attempt (edits re-evaluate).
    if (!confirmed && isLargeExpense(val)) {
      showLargeConfirm(val, amount, note, btn, msg, form);
      return;
    }

    submitting = true;
    btn.disabled = true;                          // block double-tap
    msg.hidden = true;

    // Snapshot for rollback. The Phase-1A cache is NOT written here — it keeps
    // the last server-authoritative state, so a reload during a pending POST
    // never restores an unconfirmed optimistic transaction.
    var prevState = store.state;
    var prevTx = store.tx.slice();
    prevRemaining = Number(prevState.remaining_pace);

    // 1. Optimistic: temp transaction + optimistic state, rendered instantly.
    //    The transaction belongs to the user's LOCAL day (not server/UTC).
    var dayKey = localDayKey();
    var tempId = newTempId();
    var noteVal = note.value.trim();
    var tempTx = {
      __tempId: tempId, __pending: true, row: null,
      date: dayKey, amount: val, note: noteVal, type: "expense"
    };
    store.tx.push(tempTx);
    store.state = computeOptimistic(prevState, val);
    render({ showDelta: true, keepDelta: true, inkLast: true });

    // 2. Everything derived from the optimistic state appears in this same
    //    update: main Pace, Today's entries (rendered above), and the Undo bar.
    //    The sheet closes NOW (no timer) so the page underneath is visible.
    var undoT = { tempId: tempId, id: null, amount: val, cancelled: false };
    showUndoBar(undoT);
    amount.value = ""; note.value = "";
    clearTimeout(closeTimer);
    closeSheet();

    // 3. Background POST — one logical POST, no follow-up GET. Server reconciles.
    //    client_id makes the single conservative retry duplicate-safe.
    apiPost({ action: "addTransaction", transaction: { amount: val, note: noteVal, type: "expense", client_id: newClientId(), date: dayKey }, today: dayKey })
      .then(function (data) {
        // replace the optimistic temp with the authoritative transaction + state
        store.tx = store.tx.filter(function (t) { return t.__tempId !== tempId; });
        if (data.transaction) store.tx.push(data.transaction);
        if (data.state) store.state = data.state;   // server wins
        var realId = data.transaction && data.transaction.transaction_id;
        if (undoT.cancelled) {
          // User tapped Undo before the server confirmed: the row now exists
          // server-side, so delete it by its real id. performDelete removes it
          // and shifts Pace in this same tick (no visible flash), then confirms.
          saveCache();
          if (realId) performDelete(realId);
          return;
        }
        undoT.id = realId || null;                   // promote temp -> real id (bar stays as-is)
        saveCache();                                 // persist confirmed state (Phase 1A)
        clearSyncNote();
        render({ keepDelta: true });                 // no re-ink; keep the delta flash
      })
      .catch(function () {
        if (undoT.cancelled) return;                 // already undone locally; nothing recorded
        // rollback: drop the optimistic tx + restore prior state; nothing was cached
        store.tx = prevTx;
        store.state = prevState;
        if (undoTarget === undoT) { clearTimeout(undoTimer); hideUndoBar(); }
        render();                                    // clears the optimistic delta too
        showLogError("Couldn’t save “" + (noteVal || money(val)) + "”. Not recorded.");
      })
      .then(function () { submitting = false; });     // always release the guard
  }

  var flashTimer = null;
  function flash(elm, text, kind) {
    elm.textContent = text;
    elm.className = "form-msg " + kind;
    elm.hidden = false;
    clearTimeout(flashTimer);
    if (kind === "ok") flashTimer = setTimeout(function () { elm.hidden = true; }, 3000);
  }

  function openSheet(kind) {
    clearTimeout(closeTimer);
    openKind = kind;
    lastFocus = document.activeElement;
    fillSheet(kind);
    sheet.hidden = false;
    requestAnimationFrame(function () { sheet.classList.add("open"); });
    var focusTarget = kind === "add"
      ? sheetContent.querySelector("#amountInput")
      : sheet.querySelector(".sheet__x");
    if (focusTarget) focusTarget.focus();
  }
  function closeSheet() {
    if (sheet.hidden) return;
    openKind = null;
    sheet.classList.remove("open");
    var done = function () { sheet.hidden = true; sheet.removeEventListener("transitionend", done); };
    sheet.addEventListener("transitionend", done);
    setTimeout(done, 340);
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  // ---- access gate + account actions ------------------------------------

  function onAuthLost(actualUser) {
    // Session invalid/expired/mismatched: drop it and this profile's local data
    // (plus the profile the server actually resolved, if it differs), then
    // reload so nothing from the old session stays on screen.
    try {
      localStorage.removeItem(cacheKey());
      if (actualUser) localStorage.removeItem("pace_cache_v1_" + actualUser);
    } catch (e) {}
    clearSession(); session = null;
    location.reload();
  }
  function switchUser() {
    try { localStorage.removeItem(cacheKey()); } catch (e) {}   // don't leave this profile's numbers behind
    clearSession(); session = null;
    location.reload();                                          // clean slate -> gate
  }
  function resetDemo(btn) {
    btn.disabled = true; btn.textContent = "Resetting…";
    apiPostOnce({ action: "resetGuest", today: localDayKey() })
      .then(function (d) {
        store.state = d.state; store.settings = d.settings; store.tx = d.transactions || [];
        saveCache(); hideUndoBar(); render();
      })
      .catch(function (err) { showLogError("Couldn’t reset the demo — " + niceNetwork(err)); })
      .then(function () { btn.disabled = false; btn.textContent = "Reset demo"; });
  }

  var gateProfile = null;
  function updateProfileTag() {
    var t = $("profileTag"); if (!t) return;
    var demo = session && session.mode === "guest";
    t.hidden = !demo; t.textContent = demo ? "demo" : "";
  }
  function showApp() { $("gate").hidden = true; $("app").hidden = false; updateProfileTag(); }
  function showGate() {
    $("app").hidden = true; $("gate").hidden = false;
    gateChoices();
  }
  function gateChoices() {
    gateProfile = null;
    $("gateChoices").hidden = false; $("gateForm").hidden = true;
    $("gateErr").hidden = true; $("gateCode").value = "";
  }
  function gateError(msg) { var e = $("gateErr"); e.textContent = msg; e.hidden = false; }
  function enterSession(data) {
    session = { token: data.token, user: data.user, mode: data.mode };
    saveSession(session);
    $("gateCode").value = "";
    showApp();
    load();
  }
  function startCode(profile) {
    gateProfile = profile;
    $("gateChoices").hidden = true; $("gateForm").hidden = false; $("gateErr").hidden = true;
    $("gateWho").textContent = PROFILE_LABEL[profile];
    $("gateCode").focus();
  }
  function doLogin() {
    var code = $("gateCode").value;
    if (!gateProfile || !code) { gateError("Enter your access code."); return; }
    var go = $("gateGo"); go.disabled = true; go.textContent = "Checking…"; $("gateErr").hidden = true;
    apiPostOnce({ action: "login", profile: gateProfile, code: code })
      .then(enterSession)
      .catch(function (err) {
        gateError(err && err.business ? err.message : niceNetwork(err));
        $("gateCode").select();
      })
      .then(function () { go.disabled = false; go.textContent = "Continue"; });
  }
  function doGuest() {
    // Feel immediate: paint the (skeleton) app now, get the guest session in the background.
    showApp();
    apiPostOnce({ action: "guest" })
      .then(enterSession)
      .catch(function (err) {
        showGate();
        gateError(err && err.business ? err.message : niceNetwork(err));
      });
  }

  // ---- boot ------------------------------------------------------------

  function load() {
    if (!API) { fatal("Not configured — paste your /exec URL into config.js"); return; }

    // 1. Hydrate instantly from cache if we have a valid one (no skeleton).
    var cached = loadCache();
    var hydrated = false;
    if (cached) {
      store.state = cached.state;
      store.settings = cached.settings;
      store.tx = cached.tx;
      render();          // paints last-known numbers immediately
      hydrated = true;
    }

    // 2. Always revalidate in the background against the authoritative server.
    apiGet("all")
      .then(function (d) {
        if (d.user && session && d.user.key !== session.user) { onAuthLost(d.user.key); return; }
        store.state = d.state;
        store.settings = d.settings;
        store.tx = d.transactions || [];
        clearSyncNote();
        render();        // server data wins
        saveCache();     // refresh the mirror
      })
      .catch(function (err) {
        if (hydrated) {
          // keep the cached view usable; just flag that sync didn't happen
          showSyncNote();
        } else {
          // no cache to fall back on — preserve the original first-load error
          fatal(niceNetwork(err));
        }
      });
  }

  document.addEventListener("DOMContentLoaded", function () {
    Array.prototype.forEach.call(document.querySelectorAll("[data-sheet]"), function (b) {
      b.addEventListener("click", function () { openSheet(b.getAttribute("data-sheet")); });
    });
    $("add").addEventListener("click", function () { openSheet("add"); });
    Array.prototype.forEach.call(sheet.querySelectorAll("[data-close]"), function (b) {
      b.addEventListener("click", closeSheet);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !sheet.hidden) closeSheet();
    });

    // gate wiring
    Array.prototype.forEach.call(document.querySelectorAll("[data-profile]"), function (b) {
      b.addEventListener("click", function () { startCode(b.getAttribute("data-profile")); });
    });
    $("gateGuest").addEventListener("click", doGuest);
    $("gateBack").addEventListener("click", gateChoices);
    $("gateForm").addEventListener("submit", function (e) { e.preventDefault(); doLogin(); });

    // The old single global cache belonged to the pre-multi-user app; never reuse it.
    try { localStorage.removeItem("pace_cache_v1"); } catch (e) {}

    session = loadSession();
    if (session) { showApp(); load(); }   // returning user: instant shell + cached numbers
    else { showGate(); }
  });
})();
